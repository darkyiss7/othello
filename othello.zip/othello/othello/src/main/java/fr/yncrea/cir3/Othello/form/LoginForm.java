package fr.yncrea.cir3.othello.form;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class LoginForm {
    private long id;
    private String username;
    private String password;
}
