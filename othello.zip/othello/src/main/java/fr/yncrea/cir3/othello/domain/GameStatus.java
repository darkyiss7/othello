package fr.yncrea.cir3.othello.domain;

public enum GameStatus {
    STARTED, DRAW, FINISHED
}
