package fr.yncrea.cir3.othello;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class othelloApplication {

	public static void main(String[] args) {
		SpringApplication.run(othelloApplication.class, args);
	}

}
